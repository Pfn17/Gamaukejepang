import collections
import time
from dataclasses import dataclass
from typing import Optional

from src import indicators as ind

# Rolling open-interest history per symbol, so we can compute a REAL
# rate-of-change ratio (OI now vs OI ~N scan-cycles ago) instead of a
# single snapshot compared against itself.
#
# Math note: this is just a discrete-time derivative estimate --
# d(OI)/dt ~= (OI(t) - OI(t-h)) / OI(t-h), the same finite-difference idea
# used for velocity in physics. You cannot get a rate of change from ONE
# measurement; you need two measurements separated in time. That was the
# bug: the old code divided a single OI reading by itself, which is
# identically 1.0 for every symbol, always.
_OI_HISTORY_MAXLEN = 20  # ~20 scan cycles of history (see main.py SCAN_INTERVAL_SECONDS)
_oi_history = {}


def _open_interest_ratio(symbol: str, open_interest: float) -> float:
    if open_interest is None or open_interest <= 0:
        return 1.0
    hist = _oi_history.setdefault(symbol, collections.deque(maxlen=_OI_HISTORY_MAXLEN))
    hist.append((time.time(), open_interest))
    if len(hist) < 2:
        return 1.0  # not enough history yet -> neutral, not "unchanged"
    oldest_oi = hist[0][1]
    if oldest_oi <= 0:
        return 1.0
    return open_interest / oldest_oi


@dataclass
class MarketContext:
    symbol: str
    price: float
    change_24h: float
    funding_rate: float
    open_interest: float = 0.0
    # Kept only for backward compatibility with any old caller that still
    # constructs a MarketContext with these fields. No longer trusted by
    # quantify_market() below -- it derives these straight from candles
    # instead (see the fix note further down).
    volume_ratio: Optional[float] = None
    open_interest_ratio: Optional[float] = None
    momentum: Optional[float] = None
    volatility: Optional[float] = None


@dataclass
class QuantSignal:
    symbol: str
    label: str
    score: float
    confidence: float
    reasons: list
    sentiment_score: float = 0.0
    fundamental_score: float = 0.0


def _safe_score(value: float, positive: bool = True) -> float:
    if value is None:
        return 0.0
    value = max(-1.0, min(1.0, value))
    return value if positive else -value


def quantify_market(symbol: str, candles: list, context: Optional[MarketContext] = None) -> QuantSignal:
    if not candles:
        return QuantSignal(symbol=symbol, label="neutral", score=0.0, confidence=0.0, reasons=["no candle data"])

    closes = ind.closes(candles)
    vols = ind.volumes(candles)
    ema9 = ind.ema(closes, 9)
    ema21 = ind.ema(closes, 21)
    rsi14 = ind.rsi(closes, 14)
    atr14 = ind.atr(candles, 14)
    vwap = ind.vwap_session(candles)
    vol_sma = ind.volume_sma(candles, 20)
    last_idx = len(candles) - 1

    if context is None:
        context = MarketContext(symbol=symbol, price=float(closes[-1]), change_24h=0.0, funding_rate=0.0)

    # --- Derived features, computed straight from candles instead of the
    # ticker-derived fields on `context` (those three were dimensionally
    # broken -- see fix notes). Doing it here means main.py/dashboard.py
    # can never re-introduce the bug by constructing MarketContext badly.

    # volume_ratio: how loud is the LAST closed candle vs its own 20-bar
    # average? A true dimensionless ratio (volume / volume), unlike
    # quoteVolume/volume which is a PRICE (USDT per token), not a ratio.
    if vol_sma[last_idx] == vol_sma[last_idx] and vol_sma[last_idx] > 0:  # not NaN
        volume_ratio = float(vols[last_idx] / vol_sma[last_idx])
    else:
        volume_ratio = 1.0

    # volatility: ATR expressed as a fraction of price (a normalized,
    # always-non-negative dispersion measure -- comparable across symbols
    # of any price level). Replaces the old `priceChangePercent/1000` hack,
    # which could go negative and was just a rescaled copy of change_24h.
    if atr14[last_idx] == atr14[last_idx] and closes[last_idx] > 0:  # not NaN
        volatility = float(atr14[last_idx] / closes[last_idx])
    else:
        volatility = 0.0

    # momentum: short-horizon (5-candle) rate of change, distinct in kind
    # and timeframe from the 24h change_24h feature below -- so the two
    # aren't just the same number counted twice.
    lookback = max(0, last_idx - 5)
    base = closes[lookback]
    momentum = float((closes[last_idx] - base) / base) if base > 0 else 0.0

    open_interest_ratio = _open_interest_ratio(symbol, context.open_interest)

    score = 0.0
    sentiment_score = 0.0
    fundamental_score = 0.0
    reasons = []

    if not (ema9[last_idx] != ema9[last_idx] or ema21[last_idx] != ema21[last_idx]):
        if ema9[last_idx] > ema21[last_idx]:
            score += 0.25
            sentiment_score += 0.25
            reasons.append("EMA9>EMA21")
        elif ema9[last_idx] < ema21[last_idx]:
            score -= 0.25
            sentiment_score -= 0.25
            reasons.append("EMA9<EMA21")

    if not (rsi14[last_idx] != rsi14[last_idx]):
        if 50 <= rsi14[last_idx] <= 70:
            score += 0.15
            sentiment_score += 0.15
            reasons.append("RSI in healthy bullish zone")
        elif rsi14[last_idx] > 70:
            score -= 0.1
            sentiment_score -= 0.1
            reasons.append("RSI overbought")
        elif rsi14[last_idx] < 30:
            score -= 0.1
            sentiment_score -= 0.1
            reasons.append("RSI oversold")

    if context.change_24h > 0.5:
        score += 0.2
        sentiment_score += 0.2
        reasons.append("positive 24h move")
    elif context.change_24h < -0.5:
        score -= 0.2
        sentiment_score -= 0.2
        reasons.append("negative 24h move")

    if volume_ratio > 1.2:
        score += 0.15
        sentiment_score += 0.15
        reasons.append("volume expansion")
    elif volume_ratio < 0.8:
        score -= 0.15
        sentiment_score -= 0.15
        reasons.append("volume contraction")

    if context.funding_rate > 0.0001:
        score += 0.05
        fundamental_score += 0.05
        reasons.append("positive funding")
    elif context.funding_rate < -0.0001:
        score -= 0.05
        fundamental_score -= 0.05
        reasons.append("negative funding")

    if open_interest_ratio > 1.1:
        score += 0.05
        fundamental_score += 0.05
        reasons.append("OI rising")
    elif open_interest_ratio < 0.9:
        score -= 0.05
        fundamental_score -= 0.05
        reasons.append("OI falling")

    # momentum here is a SHORT-horizon (5-candle) move, so threshold is
    # intentionally smaller than the old copy-of-24h-change version.
    if momentum > 0.01:
        score += 0.1
        sentiment_score += 0.1
        reasons.append("short-term momentum positive")
    elif momentum < -0.01:
        score -= 0.1
        sentiment_score -= 0.1
        reasons.append("short-term momentum negative")

    # volatility is now ATR/price (always >= 0), so this reads as
    # "volatility is elevated enough to support a breakout continuing",
    # not "today happened to be a positive day" (the old bug).
    if volatility > 0.008:
        score += 0.05
        sentiment_score += 0.05
        reasons.append("volatility supports breakout")

    if abs(score) > 0.5:
        label = "bullish" if score > 0 else "bearish"
    else:
        label = "neutral"

    confidence = min(0.99, 0.55 + min(0.35, abs(score) / 2.0))
    return QuantSignal(symbol=symbol, label=label, score=max(-1.0, min(1.0, score)), confidence=confidence, reasons=reasons, sentiment_score=max(-1.0, min(1.0, sentiment_score)), fundamental_score=max(-1.0, min(1.0, fundamental_score)))
