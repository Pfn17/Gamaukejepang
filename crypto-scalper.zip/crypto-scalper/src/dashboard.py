"""
Lightweight real-time dashboard. Runs as its own Flask process so a
dashboard bug can never crash the trading loop, and vice versa. The two
processes talk through the journal file + a small status.json file that
main.py writes to every scan cycle.

Run: python -m src.dashboard   (from project root, with .env loaded)
In Codespaces: forward DASHBOARD_PORT, open in browser.
"""
import json
import os
from flask import Flask, render_template, jsonify

from config import cfg
from src import journal

STATUS_PATH = os.path.join(os.path.dirname(__file__), "..", "journal", "status.json")

app = Flask(__name__, template_folder="../templates")


def read_status():
    if not os.path.exists(STATUS_PATH):
        return {"state": "starting", "last_scan": None, "open_positions": [], "candidates": []}
    with open(STATUS_PATH, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {"state": "unknown"}


@app.route("/")
def index():
    return render_template("dashboard.html", refresh_seconds=5)


@app.route("/api/status")
def api_status():
    status = read_status()
    stats = journal.summary_stats()
    recent = journal.read_all()[-30:][::-1]
    return jsonify({"status": status, "stats": stats, "recent_events": recent})


def run():
    app.run(host="0.0.0.0", port=cfg.DASHBOARD_PORT, debug=False)


if __name__ == "__main__":
    run()
