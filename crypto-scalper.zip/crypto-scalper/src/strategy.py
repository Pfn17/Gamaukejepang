"""
Scalping signal logic.

Design goal: fewer, higher-quality signals rather than "trade on every
candle". This is a LONG-ONLY momentum-pullback confluence setup, built on
well-established TA confluence (trend filter + pullback entry + volume
confirmation + volatility-based stop), not a proprietary "magic" indicator.
No guarantees of profitability are implied — this determines *when the
odds are more favorable*, not *whether a trade will win*.

IMPORTANT: every calculation here uses only data up to and including the
last CLOSED candle. We never look at the still-forming candle, to avoid
lookahead bias.

Setup logic (LONG):
1. TREND FILTER   — EMA9 > EMA21 > EMA50 on the closed series (uptrend structure)
2. MOMENTUM       — symbol is in the top-gainers scan (already-confirmed momentum)
3. PULLBACK ENTRY — price pulled back near EMA9 or rolling VWAP (not chasing a spike)
4. RSI FILTER     — RSI(14) between 45 and 68 (recovering from a dip, NOT already
                     overbought >70 which is where scalp longs get trapped)
5. VOLUME CONFIRM — last closed candle's volume > 1.3x the 20-period volume average
                     (real participation, not a dead pullback)
6. STRUCTURE STOP — stop placed below the recent swing low OR 1.5x ATR, whichever
                     is TIGHTER (keeps risk small, which is what makes a 1:1.25+ R:R
                     achievable on a scalp timeframe)
7. MIN R:R FILTER — signal is only valid if resulting reward:risk >= MIN_RISK_REWARD_RATIO

If any single condition fails, there is NO signal. This is intentional —
the point of "high probability" is to trade less often, not more.
"""
from dataclasses import dataclass
from typing import Optional

from config import cfg
from src import indicators as ind


@dataclass
class Signal:
    symbol: str
    side: str  # "LONG"
    entry: float
    stop_loss: float
    take_profit: float
    risk_reward: float
    reasons: list


def evaluate(symbol: str, candles: list) -> Optional[Signal]:
    """
    candles: list of closed candles, oldest -> newest, from BinanceClient.klines()
    NOTE: caller must ensure the LAST element is a fully CLOSED candle
    (i.e. drop the currently-forming one before calling this).
    """
    min_len = 60  # need enough history for EMA50 + ATR14 + volume SMA20 to warm up
    if len(candles) < min_len:
        return None

    closes = ind.closes(candles)
    ema9 = ind.ema(closes, 9)
    ema21 = ind.ema(closes, 21)
    ema50 = ind.ema(closes, 50)
    rsi14 = ind.rsi(closes, 14)
    atr14 = ind.atr(candles, 14)
    vwap = ind.vwap_session(candles)
    vol_sma = ind.volume_sma(candles, 20)

    i = len(candles) - 1  # last closed candle index
    last = candles[i]
    price = last["close"]

    # guard against NaN warm-up values
    vals = [ema9[i], ema21[i], ema50[i], rsi14[i], atr14[i], vwap[i], vol_sma[i]]
    if any(v is None or v != v for v in vals):  # v != v catches NaN
        return None

    reasons = []

    # 1. Trend filter
    if not (ema9[i] > ema21[i] > ema50[i]):
        return None
    reasons.append("EMA9>EMA21>EMA50 uptrend structure")

    # 3. Pullback entry — price within 0.6% of EMA9 or VWAP, from above (not below, i.e.
    # not a breakdown) — proxy for "pulled back but hasn't broken trend"
    dist_ema9 = abs(price - ema9[i]) / ema9[i]
    dist_vwap = abs(price - vwap[i]) / vwap[i]
    near_pullback_zone = (dist_ema9 <= 0.006) or (dist_vwap <= 0.006)
    if not near_pullback_zone:
        return None
    reasons.append("price near EMA9/VWAP pullback zone")

    # 4. RSI filter
    if not (45 <= rsi14[i] <= 68):
        return None
    reasons.append(f"RSI14={rsi14[i]:.1f} in favorable 45-68 band")

    # 5. Volume confirmation
    if last["volume"] <= 1.3 * vol_sma[i]:
        return None
    reasons.append("volume > 1.3x 20-period average")

    # 6. Structure stop: recent swing low (last 8 candles) vs ATR-based stop, pick tighter
    recent_low = min(c["low"] for c in candles[max(0, i - 8) : i + 1])
    atr_stop = price - 1.5 * atr14[i]
    swing_stop = recent_low * 0.999  # tiny buffer below swing low
    stop_loss = max(atr_stop, swing_stop)  # the TIGHTER (higher) of the two, still below price

    if stop_loss >= price:
        return None  # degenerate case, refuse to trade

    risk = price - stop_loss
    if risk <= 0:
        return None

    take_profit = price + risk * cfg.MIN_RISK_REWARD_RATIO
    rr = (take_profit - price) / risk

    # 7. Min R:R filter (redundant given formula above, but explicit safety check
    # in case of float weirdness)
    if rr < cfg.MIN_RISK_REWARD_RATIO - 1e-6:
        return None
    reasons.append(f"R:R={rr:.2f} meets minimum {cfg.MIN_RISK_REWARD_RATIO}")

    return Signal(
        symbol=symbol,
        side="LONG",
        entry=price,
        stop_loss=stop_loss,
        take_profit=take_profit,
        risk_reward=rr,
        reasons=reasons,
    )
